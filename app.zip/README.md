# mma-elo-api

Currently got a little progress done. Most of the data is scraped but keep getting booted out of Sherdog I think.

To do list:
<ul>
    <li>Finish scraping of data</li>
    <li>Add component for each result</li>
    <li>Add react-router</li>
    <li>Make data freely available (all fights and fighters)</li>
    <li>Make migrations for database so other people can clone and run it themselves</li>
    <li>Run ELO simulation on all the data. Already written but pointless running if all the data isn't there yet</li>
</ul>

If you want to run it and see nothing:

<ul>
    <li>git clone https://github.com/wolsney/mma-elo-api.git</li>
    <li>Run the command npm run dev</li>
    <li>Run the command php artisan serve</li>
</ul>
