<footer class="footer">
    <div class="container">
    <span class="text-muted">MMA ELO API</span>
    </div>
</footer>